

  <!-- Jquery Core Js -->
  <!-- <script src="<?= BASEURL; ?>/plugins/jquery/jquery.min.js"></script> -->

<!-- Bootstrap Core Js -->
<script src="<?= BASEURL; ?>/plugins/bootstrap/js/bootstrap.js"></script>

<!-- Select Plugin Js -->
<script src="<?= BASEURL; ?>/plugins/bootstrap-select/js/bootstrap-select.js"></script>

<!-- Slimscroll Plugin Js -->
<script src="<?= BASEURL; ?>/plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

<!-- Waves Effect Plugin Js -->
<script src="<?= BASEURL; ?>/plugins/node-waves/waves.js"></script>



<!-- Jquery DataTable Plugin Js -->
<script src="<?= BASEURL; ?>/plugins/jquery-datatable/jquery.dataTables.js"></script>
<script src="<?= BASEURL; ?>/plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js"></script>
<script src="<?= BASEURL; ?>/plugins/jquery-datatable/extensions/export/dataTables.buttons.min.js"></script>
<script src="<?= BASEURL; ?>/plugins/jquery-datatable/extensions/export/buttons.flash.min.js"></script>
<script src="<?= BASEURL; ?>/plugins/jquery-datatable/extensions/export/jszip.min.js"></script>
<script src="<?= BASEURL; ?>/plugins/jquery-datatable/extensions/export/pdfmake.min.js"></script>
<script src="<?= BASEURL; ?>/plugins/jquery-datatable/extensions/export/vfs_fonts.js"></script>
<script src="<?= BASEURL; ?>/plugins/jquery-datatable/extensions/export/buttons.html5.min.js"></script>
<script src="<?= BASEURL; ?>/plugins/jquery-datatable/extensions/export/buttons.print.min.js"></script>

<!-- Custom Js -->
<script src="<?= BASEURL; ?>/js/admin.js"></script>
<script src="<?= BASEURL; ?>/js/pages/tables/jquery-datatable.js"></script>
<script src="https://cdn.datatables.net/rowgroup/1.1.2/js/dataTables.rowGroup.min.js"></script>

<!-- Demo Js -->
<script src="<?= BASEURL; ?>/js/demo.js"></script>
<script src="<?= BASEURL; ?>/js/script.js"></script>

<script src="<?= BASEURL; ?>/js/pages/ui/dialogs.js"></script>
<script src="<?= BASEURL; ?>/js/pages/ui/modals.js"></script>

<script>
  $(function(){
    setTimeout(function(){ 
      $('.msg-alert').hide();
    }, 5000);
  });
</script>

</body>
</html>